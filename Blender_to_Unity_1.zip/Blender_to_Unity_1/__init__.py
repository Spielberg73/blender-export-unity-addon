bl_info = {
    "name": "Exportar FBX/OBJ para Unity",
    "author": "David",
    "version": (1, 1),
    "blender": (3, 0, 0),
    "location": "Vista 3D > Panel lateral > Exportar",
    "description": "Exporta modelos seleccionados en formato FBX o OBJ optimizado para Unity",
    "category": "Import-Export",
}

import bpy

class ExportSettings(bpy.types.PropertyGroup):
    export_format: bpy.props.EnumProperty(
        name="Formato de exportación",
        description="Elige el formato de exportación",
        items=[
            ('FBX', "FBX", "Exportar como FBX"),
            ('OBJ', "OBJ", "Exportar como OBJ")
        ],
        default='FBX'
    )

class ExportPanel(bpy.types.Panel):
    bl_label = "Exportar para Unity"
    bl_idname = "VIEW3D_PT_export_unity"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Exportar'

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene.export_settings, "export_format")
        layout.operator("export.unity_model", text="Exportar")

class ExportOperator(bpy.types.Operator):
    bl_idname = "export.unity_model"
    bl_label = "Exportar modelo para Unity"

    def execute(self, context):
        export_format = context.scene.export_settings.export_format
        selected_objects = context.selected_objects

        if not selected_objects:
            self.report({'WARNING'}, "No hay objetos seleccionados para exportar.")
            return {'CANCELLED'}

        filepath = bpy.path.abspath("//exportado." + export_format.lower())

        if export_format == 'FBX':
            bpy.ops.export_scene.fbx(
                filepath=filepath,
                use_selection=True,
                apply_unit_scale=True,
                global_scale=1.0,
                axis_forward='-Z',
                axis_up='Y'
            )
        elif export_format == 'OBJ':
            bpy.ops.export_scene.obj(
                filepath=filepath,
                use_selection=True,
                axis_forward='-Z',
                axis_up='Y',
                use_materials=False
            )

        self.report({'INFO'}, f"Exportado como {export_format} en {filepath}")
        return {'FINISHED'}

def register():
    bpy.utils.register_class(ExportSettings)
    bpy.types.Scene.export_settings = bpy.props.PointerProperty(type=ExportSettings)
    bpy.utils.register_class(ExportPanel)
    bpy.utils.register_class(ExportOperator)

def unregister():
    bpy.utils.unregister_class(ExportSettings)
    del bpy.types.Scene.export_settings
    bpy.utils.unregister_class(ExportPanel)
    bpy.utils.unregister_class(ExportOperator)

if __name__ == "__main__":
    register()
